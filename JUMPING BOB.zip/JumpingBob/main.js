
var config = {
    type: Phaser.AUTO,
    width: innerWidth,
    height: innerHeight-6,

    scene: {
        init: init,
        preload: preload,
        create: create,
        update: update
    },

    physics:{
      default: 'matter',
      matter:
      {
        debug:false                                                               //rende visibili le hitbox
      }
    }
};

window.onload = () => {
  document.getElementById('playBtn').focus();
  document.getElementById('playBtn').onclick = () => {
    var game = new Phaser.Game(config);
    document.getElementById('startInterface').style.visibility = "hidden";
  };

  document.getElementById('commandsBtn').onclick = () =>{
    document.getElementById('startInterface').style.visibility = "hidden";
	document.getElementById('commandsList').style.visibility = "visible";
  }

  document.getElementById('backBtn').onclick = () =>{
    document.getElementById('startInterface').style.visibility = "visible";
	document.getElementById('commandsList').style.visibility = "hidden";
  }
}

//GIOCATORE
var player;
var speed = 8;//7*screen.width/config.width;
var speedJump = -10;//-10*screen.height/config.height;
var sideRight = true;
var jumped = false;
var takeDamage = false;

//NEMICI
var enemies = [];
var enemy;
var enemySpeed = -1;
var colpito = false;

//GIOCO
var keyboard;
var cursors;
var touchGround = false;
var hp = 200;
var healthPoint = 100;
var lifeGraphics;
var lifeBar;

//OBSTACLES
var spikeDamage = 20;
var spikeDamageJump = 10;

//ARMI
  //WEAPONS
  var weapon = [];
  var numProjectile = 0;
  var textProjectile;
  var shot = false;
  var projectile;

  //RELOAD HUD
  var reloadGraphics;
  var reloadBar;
  var reloadTime;
  var reloadingTime;
  var startReload = false;


//TILEMAP
var objectLayer;
var map;
var tilesetBlock;
var ground;
var background;
var tilesetBackground;
var decorationAndObstacles;
var tilesetDecorationAndObstacles;

//OGGETTI
var star = [];
var health = [];

//ITEMS
  var items = [];

  //SWITCH
  var switchLeft = true;
  var touchSwitch = false;
  var switchIndex;
  var switchChanged = true;

  //SPRINGBOARD
  var springBoardJump = -20;
  var springBoardIndex;
  var springBoardTouched = false;

  //DOOR
  var doorIndex;
  var doorTouched;

  //DOOR SWITCH
  var doorSwitch = [[false, false, true, true]];
  var switch1Index;
  var door1Index;

//TEXT
var scoreText;
var scoreStar = 0;

function init()//posto dove inizializzare le variabili
{
  cursors = this.input.keyboard.createCursorKeys();
  keyboard = this.input.keyboard.addKeys("W, S, A, D, E, ENTER, ESC");
}

function preload ()
{
  //GIOCATORE
  this.load.atlas("player", "assets/GameSprites/Player/grey/grey.png", "assets/GameSprites/Player/grey/grey.json");//(key, file png, file json)

  //ENEMY
  this.load.atlas("spider", "assets/GameSprites/Enemy/SPIDER/spider.png", "assets/GameSprites/Enemy/SPIDER/spider.json");
  this.load.atlas("barnacle", "assets/GameSprites/Enemy/BARNACLE/barnacle.png", "assets/GameSprites/Enemy/BARNACLE/barnacle.json");
  this.load.atlas("bat", "assets/GameSprites/Enemy/BAT/bat.png", "assets/GameSprites/Enemy/BAT/bat.json");
  this.load.atlas("bee", "assets/GameSprites/Enemy/BEE/bee.png", "assets/GameSprites/Enemy/BEE/bee.json");
  this.load.atlas("fish", "assets/GameSprites/Enemy/FISH/fish.png", "assets/GameSprites/Enemy/FISH/fish.json");
  this.load.atlas("fly", "assets/GameSprites/Enemy/FLY/fly.png", "assets/GameSprites/Enemy/FLY/fly.json");
  this.load.atlas("ghost", "assets/GameSprites/Enemy/GHOST/ghost.png", "assets/GameSprites/Enemy/GHOST/ghost.json");
  this.load.atlas("greenBlocker", "assets/GameSprites/Enemy/GREEN BLOCKER/greenBlocker.png", "assets/GameSprites/Enemy/GREEN BLOCKER/greenBlocker.json");
  this.load.atlas("greenEnemy", "assets/GameSprites/Enemy/GREEN ENEMY/greenEnemy.png", "assets/GameSprites/Enemy/GREEN ENEMY/greenEnemy.json");
  this.load.atlas("mouse", "assets/GameSprites/Enemy/MOUSE/mouse.png", "assets/GameSprites/Enemy/MOUSE/mouse.json");
  this.load.atlas("pinkSlime", "assets/GameSprites/Enemy/PINK SLIME/pinkSlime.png", "assets/GameSprites/Enemy/PINK SLIME/pinkSlime.json");
  this.load.atlas("pocker", "assets/GameSprites/Enemy/POCKER/pocker.png", "assets/GameSprites/Enemy/POCKER/pocker.json");
  this.load.atlas("slimeGreen", "assets/GameSprites/Enemy/SLIME GREEN/slimeGreen.png", "assets/GameSprites/Enemy/SLIME GREEN/slimeGreen.json");
  this.load.atlas("slimeBlue", "assets/GameSprites/Enemy/SLIMEBLUE/slimeBlue.png", "assets/GameSprites/Enemy/SLIMEBLUE/slimeBlue.json");
  this.load.atlas("snail", "assets/GameSprites/Enemy/SNAIL/snail.png", "assets/GameSprites/Enemy/SNAIL/snail.json");
  this.load.atlas("snake", "assets/GameSprites/Enemy/SNAKE/snake.png", "assets/GameSprites/Enemy/SNAKE/snake.json");
  this.load.atlas("snakeLava", "assets/GameSprites/Enemy/SNAKELAVA/snakeLava.png", "assets/GameSprites/Enemy/SNAKELAVA/snakeLava.json");
  this.load.atlas("snakeSlime", "assets/GameSprites/Enemy/SNAKESLIME/snakeSlime.png", "assets/GameSprites/Enemy/SNAKESLIME/snakeSlime.json");
  this.load.atlas("spinner", "assets/GameSprites/Enemy/SPINNER/spinner.png", "assets/GameSprites/Enemy/SPINNER/spinner.json");
  this.load.atlas("spinnerHalf", "assets/GameSprites/Enemy/SPINNER HALF/spinnerHalf.png", "assets/GameSprites/Enemy/SPINNER HALF/spinnerHalf.json");
  this.load.atlas("worm", "assets/GameSprites/Enemy/WORM/worm.png", "assets/GameSprites/Enemy/WORM/worm.json");

  //IMMAGINI TILES
  this.load.image("blockTiles", "assets/GameSprites/Blocks/block.png");
  this.load.image("backgroundTiles", "assets/GameSprites/Background/backgroundBase.png");
  this.load.image("decorationAndObstaclesTiles", "assets/GameSprites/Item/SPRITE/decorationAndObstacles.png");
  this.load.image("health", "assets/GameSprites/Item/PNG SINGOLI/RACCOGLIBILI/STATIC/health.png");

  //IMMAGINI ITEMS STATICI
  this.load.image("star", "assets/GameSprites/Item/PNG SINGOLI/RACCOGLIBILI/STATIC/star.png");
  this.load.image("fireball", "assets/GameSprites/Item/PNG SINGOLI/RACCOGLIBILI/STATIC/fireball.png");

  //IMMAGINI ITEMS DINAMICI
  this.load.atlas("switch", "assets/GameSprites/Item/ANIMATION/Switch/sprite/switch.png", "assets/GameSprites/Item/ANIMATION/Switch/sprite/switch.json");
  this.load.atlas("springBoard", "assets/GameSprites/Item/ANIMATION/springBoard/sprite/springBoard.png", "assets/GameSprites/Item/ANIMATION/springBoard/sprite/springBoard.json");
  this.load.atlas("door", "assets/GameSprites/ExpansionDecorations/door.png", "assets/GameSprites/ExpansionDecorations/door.json");

  //MAPPA
  this.load.tilemapTiledJSON("tilemap", "assets/Map/map.json");
}







//INIZIO CREATE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


function create ()
{
  //CODICE UFFICIALE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

//SET
  //const {width, height} = this.scale;                                         //assegna a due variabili lo stesso valore

//CREAZIONE MAPPA
  map = this.make.tilemap({key: "tilemap"});                                    //AGGIUNGI IL FILE JSON CHE SARA LA MAPPA (key: nome chiave che hai dato al file nel preload)
  tilesetBlock = map.addTilesetImage("block", "blockTiles");                     //aggiunge il tileset (nome tileset in tiles, key che hai assegnato al tileset)

  tilesetBackground = map.addTilesetImage("backgroundBase", "backgroundTiles");
  background = map.createLayer("background", tilesetBackground);

  tilesetDecorationAndObstacles = map.addTilesetImage("decorationAndObstacles", "decorationAndObstaclesTiles");
  decorationAndObstacles = map.createLayer("decorationAndObstacles", tilesetDecorationAndObstacles);

  ground = map.createLayer('ground', tilesetBlock);                                  //visualizza un layer (nome layer in tiled, variabile a cui hai assegnato il tileset)
  ground.setCollisionByProperty({ collides: true});                                  // i tiles che hanno come proprieta collides attivano le collision

  this.matter.world.convertTilemapLayer(ground);                                //rende "reale (matter)" tutti gli oggetti di un layer

  objectLayer = map.getObjectLayer("objects");                                  //PRENDE IL LAYER DELL'OGGETTO

//INSERIMENTO OGGETTI
  objectLayer.objects.forEach(objData => {                                      //CONTROLLO TRA GLI OGGETTI PRESI
    const {x, y, name, width, height} = objData

    switch (name)
    {
      //Quando l'oggetto è lo spawn creo il giocatore
      case "playerSpawn":  player = this.matter.add.sprite(x + width/2, y-10, 'player');
                           player.setFixedRotation();                           //RIMUOVE LA ROTAZIONE DELL'OGGETTO
                           this.cameras.main.startFollow(player, true);//la camera segue il giocatore, il true attiva il round pixels(elimina alcni bordi bianchi)
                           player.name = "player";
                           break;

      case "star":         star.push(this.matter.add.sprite(x + width/2, y + height/2, "star", undefined, {
                           isStatic: true,
                           isSensor: true, //attiva le collisioni senza bloccare il giocatore
                           name: "star"
                           }).setFixedRotation()); //aggiunge una stella
                           break;

      case 'fireTaker':    weapon.push(this.matter.add.sprite(x + width/2, y + height/2, "fireball", undefined, {
                             isStatic: true,
                             isSensor: true,
                             name: "fire"
                           }).setFixedRotation());
                           break;

      case "spiderSpawn":  enemy = this.matter.add.sprite(x + (width * 0.5), y-10, 'spider');
                           enemy.setFixedRotation();
                           enemy.name = "spider";
                           enemies.push(enemy);
                           break;

      case "border":       this.matter.add.rectangle(x + width/2, y + height/2, width, height, {
                              isStatic: true,
                              name: "border"
                           });
                           break;

      case 'spikes':       this.matter.add.rectangle(x + width/2, y + height/2, width, height, { //aggiungo altezza/2 e larghezza/2 perché posiziona il centro nel punto in alto a sinistra
                             isStatic: true,
                             isSensor: true,
                             name: "spikes"
                           });
                           break;

      case 'health':       health.push(this.matter.add.sprite(x + width/2, y + height/2, "health", undefined, {
                             isStatic: true,
                             isSensor: true,
                             name: "health"
                           }).setFixedRotation());
                           break;

      case 'switch':       items.push(this.matter.add.sprite(x + width/2, y + height/2, "switch", undefined, {
                             isStatic: true,
                             isSensor: true,
                             name: "switch"
                           }).setFixedRotation());
                           break;

      case 'switch1':      items.push(this.matter.add.sprite(x + width/2, y + height/2, "switch", undefined, {
                             isStatic: true,
                             isSensor: true,
                             name: "switch1"
                           }).setFixedRotation());
                           break;

      case 'springBoard':  items.push(this.matter.add.sprite(x + width/2, y + height/2, "springBoard", undefined, {
                             isStatic: true,
                             isSensor: true,
                             name: "springBoard"
                           }).setFixedRotation());
                           break;

      case "fishSpawn":  enemy = this.matter.add.sprite(x + (width * 0.5), y-10, 'fish');
                          enemy.setFixedRotation();
                          enemy.name = "fish";
                          enemies.push(enemy);
                          break;

      case "doorSpawn": items.push(this.matter.add.sprite(x + width/2, y + height/2, "door", undefined, {
                             isStatic: true,
                             isSensor: true,
                             name: "door"
                           }).setFixedRotation());
                           break;

     case "doorLocked": this.matter.add.sprite(x + width/2, y + height/2, "door", undefined, {
                            isStatic: true,
                            name: "doorLocked"
                          }).setFixedRotation();
                          break;


     case "doorSpawn1": items.push(this.matter.add.sprite(x + width/2, y + height/2, "door", undefined, {
                            isStatic: true,
                            name: "door1"
                          }).setFixedRotation());
                          door1Index = items.length-1;
                          break;

     case "stairs" :      this.matter.add.rectangle(x + width/2, y + height/2, width, height, {
                             isStatic: true,
                             isSensor: true,
                             name: "stairs"
                          });
                          break;

     case "end" :         this.matter.add.rectangle(x + width/2, y + height/2, width, height, {
                             isStatic: true,
                             isSensor: true,
                             name: "end"
                          });
                          break;

      default:             break;
    }
  })

//CAMERA
  this.cameras.main.setBounds(0, 0, map.widthInPixels, map.heightInPixels);

//BORDI MAPPA
  this.matter.world.setBounds(0, 0, map.widthInPixels, map.heightInPixels)

//ANIMAZIONI
  //PLAYER
  this.anims.create({                                                           // CREA L'ANIMAZIONE DELLA CAMMINATA
      key: "walk",                                                              //il nome di questa animazione
      frames: [   //carica un array di immagini definendo (key: nomefile json, frame: nome frame nel file json)
        { key: "player", frame: "alienBeige_walk1.png" },
        { key: "player", frame: "alienBeige_walk2.png" },
      ],
      frameRate: 10,                                                            //il framerate
      repeat: -1
                                          //ripete all'infinito
    });

  this.anims.create({                                                           //CREA L'ANIMAZIONE DI QUANDO E FERMO
      key: "idle",
      frames: [
        { key: "player", frame: "alienBeige_stand.png" },
      ],
      frameRate: 8,
      repeat: -1
    });

  this.anims.create({                                                           //CREA L'ANIMAZIONE DI QUANDO E FERMO
      key: "hurth",
      frames: [
        { key: "player", frame: "alienBeige_hurt.png" },
      ],
      frameRate: 8,
      repeat: -1
    });

  this.anims.create({                                                           //CREA L'ANIMAZIONE DI QUANDO E FERMO
      key: "jump",
      frames: [
        { key: "player", frame: "alienBeige_jump.png"},
      ],
      frameRate: 8,
      repeat: -1
    });

  //ENEMY
  this.anims.create({
    key: "spiderWalk",
    frames: [
      { key: "spider", frame: "spider_walk1.png"},
      { key: "spider", frame: "spider_walk2.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "barnacleWalk",
    frames: [
      { key: "barnacle", frame: "baarnacle.png"},
      { key: "barnacle", frame: "barnacle_bite.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "batWalk",
    frames: [
      { key: "bat", frame: "bat.png"},
      { key: "bat", frame: "bat_fly.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "beeWalk",
    frames: [
      { key: "bee", frame: "bee.png"},
      { key: "bee", frame: "bee_fly.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "fishWalk",
    frames: [
      { key: "fish", frame: "fishSwim1.png"},
      { key: "fish", frame: "fishSwim2.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "flyWalk",
    frames: [
      { key: "fly", frame: "flyFly1.png"},
      { key: "fly", frame: "flyFly2.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "ghostWalk",
    frames: [
      { key: "ghost", frame: "ghost.png"},
      { key: "ghost", frame: "ghost_normal.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "mouseWalk",
    frames: [
      { key: "mouse", frame: "mouse.png"},
      { key: "mouse", frame: "mouse_walk.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "pinkSlimeWalk",
    frames: [
      { key: "pinkSlime", frame: "slimeWalk1.png"},
      { key: "pinkSlime", frame: "slimeWalk2.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "snailWalk",
    frames: [
      { key: "snail", frame: "snailWalk1.png"},
      { key: "snail", frame: "snailWalk2.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "snakeWalk",
    frames: [
      { key: "snake", frame: "snake.png"},
      { key: "snake", frame: "snake_walk.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "snakeLavaMove",
    frames: [
      { key: "snakeLava", frame: "snakeLava.png"},
      { key: "snakeLava", frame: "snakeLava_ani.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "snakeSlimeMove",
    frames: [
      { key: "snakeSlime", frame: "snakeSlime.png"},
      { key: "snakeSlime", frame: "snakeSlime_ani.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "spinnerMove",
    frames: [
      { key: "spinner", frame: "spinner.png"},
      { key: "spinner", frame: "spinner_spin.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "spinnerHalfMove",
    frames: [
      { key: "spinnerHalf", frame: "spinnerHalf.png"},
      { key: "spinnerHalf", frame: "spinnerHalf_spin.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  this.anims.create({
    key: "wormMove",
    frames: [
      { key: "worm", frame: "worm.png"},
      { key: "worm", frame: "worm_walk.png"},
    ],
    frameRate: 8,
    repeat: -1
  });

  //ITEMS
  //SWITCH
  this.anims.create({
    key: "switchRight",
    frames: [
      { key: "switch", frame: "switchLeft.png"},
      { key: "switch", frame: "switchMid.png"},
      { key: "switch", frame: "switchRight.png"},
    ],
    frameRate: 10,
    duration: 1500,
    repeat: 0
  });

  this.anims.create({
    key: "switchLeft",
    frames: [
      { key: "switch", frame: "switchRight.png"},
      { key: "switch", frame: "switchMid.png"},
      { key: "switch", frame: "switchLeft.png"},
    ],
    frameRate: 10,
    duration: 1500,
    repeat: 0
  });

  //SPRINGBOARD
  this.anims.create({
    key: "springBoardBase",
    frames: [
      { key: "springBoard", frame: "springboardBase.png"},
    ],
    frameRate: 10,
    repeat: 0
  });

  this.anims.create({
    key: "springBoardJump",
    frames: [
      { key: "springBoard", frame: "springboardBase.png"},
      { key: "springBoard", frame: "springboardJump.png"},
    ],
    frameRate: 10,
    duration: 1500,
    repeat: 0
  });

  //DOOR
  this.anims.create({
    key: "doorUnlocked",
    frames: [
      { key: "door", frame: "doorUnlocked.png"},
    ],
    frameRate: 10,
    duration: 1000,
    repeat: 0
  });

  this.anims.create({
    key: "doorLocked",
    frames: [
      { key: "door", frame: "doorLocked.png"},
    ],
    frameRate: 10,
    repeat: 0
  });

//
  //INIZIO MODO DI EVITARE DOPPIO SALTO
  //controlla quando il giocatore effettua una collisione, (pair.bodyA restituisce con cosa)
  player.setOnCollideActive(pair =>{
    if(pair.bodyA.name) //QUANDO ABBIAMO EFFETTUATO IL CAMBIO MAPPA E' ANDATO NEL BODY A NON SO PERCHÈ
    {
      touchGround = false;
    }
    else
    {
      switch (pair.bodyB.name)
      {
        case "star":    collect(pair.bodyB, star); //IN QUESTA FUNZIONE CONTROLLO SE L'OGGETTI DEL BODY B E' UGUALE AD UNA STELLA
                        touchGround = false;
                        break;

        case 'fire':    distruggi(pair.bodyB, weapon);
                        numProjectile = numProjectile + 4;
                        touchGround = false;
                        break;

        case "switch":  touchSwitch = true;
                        break;

        case "switch1": doorSwitch[0][1] = true;
                        break;

        case "health":  distruggi(pair.bodyB, health);
                        hp = hp + healthPoint;
                        if (hp > 200)
                        {
                          hp = 200;
                        }
                        touchGround = false;
                        break;


        case "spikes":  player.setVelocityY(-spikeDamageJump);
                        player.tint = 0xff0000;
                        touchGround = false;
                        if(hp < spikeDamage+1)
                        {
                          hp = 0;
                        }
                        else
                        {
                          hp = hp-spikeDamage;
                        }
                        takeDamage = true;
                        break;

        case "door":    touchGround = false;
                        break;

        case "door1":   touchGround = false;
                        break;

        case "border":  touchGround = false;
                        break;

        case "stairs":  touchGround = true;
                        break;

        case "end":     this.scene.pause();
                        document.getElementById('win').style.visibility = "visible";
                        document.getElementById("riavviaVittoriaBtn").focus();
                        document.getElementById("riavviaVittoriaBtn").onclick = () =>{
                          location.reload();
                        }
                        break;

        default:        touchGround = true;
                        break;
      }
    }
  })

  //controlla quando una qualsiasi collisione con il giocatore finisce
  player.setOnCollideEnd(fine =>{
    touchGround = false;
    player.tint =0xffffff;
    this.time.delayedCall(1500, () => {
      takeDamage = false;
    });
  })
  //FINE MODO DI EVITARE DOPPIO SALTO


  //COLLISIONE CON UN NEMICO
  for (var i = 0; i < enemies.length; i++) {
    enemies[i].setOnCollideActive(pair =>{

      if (pair.bodyA.gameObject.name == "player")
      {
        if(((player.y + player.height/2)-(pair.bodyB.gameObject.y - pair.bodyB.gameObject.height/2)) < 2)
        {
          player.setVelocityX(-speed);
          distruggi(pair.bodyB, enemies);
          touchGround = false;
          colpito = false;
        }
        else if(!colpito)
        {
          if(sideRight == true)
          {
            player.setVelocityX(-speed * 1.5);
          }
          else
          {
            player.setVelocityX(speed * 1.5);
          }

          player.tint = 0xff0000;
          hp = hp-50;
          touchGround = false;
          colpito = true;
          this.time.delayedCall(200, () => {
            colpito = false;
          });
        }
      }
      else
      {
        if (pair.bodyB.gameObject.name == "player")
        {
          if(((player.y + player.height/2)-(pair.bodyA.gameObject.y - pair.bodyA.gameObject.height/2)) < 2)
          {
            player.setVelocityX(-speed);
            distruggi(pair.bodyA, enemies);
            touchGround = false;
            colpito = false;
          }
          else if(!colpito)
          {
            if(sideRight == true)
            {
              player.setVelocityX(-speed * 1.5);
            }
            else
            {
              player.setVelocityX(speed * 1.5);
            }
            player.tint = 0xff0000;
            hp = hp-50;
            touchGround = false;
            colpito = true;
            this.time.delayedCall(200, () => {
              colpito = false;
            });
          }
        }
      }
    });

    enemies[i].setOnCollideEnd(fine =>{
      player.tint =0xffffff;
      touchGround = false;
    });
  }

  //COLLISIONE CON UN ITEM
  for (var i = 0; i < items.length; i++) {
    items[i].setOnCollideActive(pair =>{
      if (pair.bodyA.gameObject.name == "player") //SE L'OGGETTO CON CUI COLLIDE LO SNOWMAN SI CHIAMA PENQUIN SI DISTRUGGE
      {
        switch(pair.bodyB.name)
        {
          case "switch":      touchSwitch = true;
                              switchIndex = posizione(pair.bodyB, items);
                              break;

          case "switch1":     doorSwitch[0][1] = true;
                              switch1Index = posizione(pair.bodyB, items);
                              break;

          case "springBoard": springBoardIndex = posizione(pair.bodyB, items);
                              player.setVelocityY(springBoardJump);
                              touchGround = false;
                              springBoardTouched = true;
                              break;

          case "door":        doorIndex = posizione(pair.bodyB, items);
                              doorTouched = true;
                              break;

          case "door1":       doorSwitch[0][0] = true;
                              break;

          default:            break;
        }
      }
    });

    items[i].setOnCollideEnd(fine =>{
      touchSwitch = false;
      springBoardTouched = false;
      doorTouched = false;
      doorSwitch[0][1] = false;
      doorSwitch[0][0] = false;
    });
  }

//HUD
  //STAR
  scoreText = this.add.text(this, this.cameras.main.scrollX + 7, this.cameras.main.scrollY, "Stars: 0/16", { //ESISTE MA PRENDE UN ALTEZZA NON RELATIVA ALLA GRANDEZZA DELL'INTERO GIOCO E NON DELLO SCHERMO
    fontSize: '32px'
  });
  scoreText.setColor("black");

  //FIREBALL
  textProjectile = this.add.text(this, scoreText.x, scoreText.y + scoreText.height , "Bullet: 0", {
    fontSize: '32px'
  });
  textProjectile.setColor("black");

  //HEALTHBAR
  lifeGraphics = this.add.graphics();
  lifeBar = this.add.graphics();
  barLife(hp);

  //RELOADBAR
  reloadGraphics = this.add.graphics();
  reloadBar = this.add.graphics();

//LOG
  //  console.log(enemies);
}












//INIZIO UPDATE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function update (dt) //dt rappresenta il tempo da quando il gioco è iniziato
{
//ANIMAZIONI
  if(springBoardTouched)
  {
    items[springBoardIndex].anims.play("springBoardJump", true);
    this.time.delayedCall(1500, () => {
      items[springBoardIndex].anims.play("springBoardBase", true);
    });
  }

  if(doorTouched)
  {
    items[doorIndex].anims.play("doorUnlocked", true);
    this.time.delayedCall(500, () => {
      items[doorIndex].anims.play("doorLocked", true);
    });
  }

  if(!doorSwitch[0][3] && doorSwitch[0][0])
  {
    items[door1Index].anims.play("doorUnlocked", true);
    this.time.delayedCall(500, () => {
      items[door1Index].anims.play("doorLocked", true);
    });
  }

//HUD
  //STAR
  scoreText.setText("Stars: " + scoreStar + "/16");
  scoreText.setY(this.cameras.main.scrollY);
  scoreText.setX(this.cameras.main.scrollX + 7);

  //BULLET
  textProjectile.setText("Bullets: " + numProjectile);
  textProjectile.setY(scoreText.y + scoreText.height);
  textProjectile.setX(scoreText.x);

  //HEALTHBAR
  barLife(hp);

  //RELOADBAR
  if (numProjectile>0)
  {
    if(startReload == true)
    {
      reloadingTime = Math.floor(dt) - reloadTime;
      barReload(reloadingTime/(1500/player.width)); //1:50 = 30 : 1500, 1500 è il tempo dopo cui posso sparare perciò devo dividere il momento in cui sono per 30
    }
    else
    {
      barReload(player.width); //VALORE MASSIMO IN MODO CHE SEGUA IL GIOCATORE RIMANENDO PIENA
    }
  }
  else
  {
    //ELIMINA LE BARRE
    reloadGraphics.clear();
    reloadBar.clear();
  }

//MOVIMENTO
  if (hp > 0)
  {
    if(touchGround == true)
    {
      jumped = false;
    }

    if (cursors.left.isDown && colpito==false || keyboard.A.isDown && colpito==false)
    {
      player.setVelocityX(-speed);
      player.flipX = true;
      sideRight = false;
      if(takeDamage == true)
      {
        player.anims.play('hurth', true);
      }
      else
      {
        if(jumped == true)
        {
          player.play('jump');
        }
        else
        {
          player.anims.play('walk', true);
        }
      }
    }
    else if (cursors.right.isDown && colpito==false || keyboard.D.isDown && colpito==false)
    {
      player.setVelocityX(speed);
      player.flipX = false;
      player.anims.play('walk', true);
      sideRight = true;
      if(takeDamage == true)
      {
        player.anims.play('hurth', true);
      }
      else
      {
        if(jumped == true)
        {
          player.play('jump');
        }
        else
        {
          player.anims.play('walk', true);
        }
      }
    }
    else
    {
      if(colpito==false)
        player.setVelocityX(0);
      if(takeDamage == true)
      {
        player.anims.play('hurth', true);
      }
      else
      {
        if(jumped == true)
        {
          player.play('jump');
        }
        else
        {
          player.anims.play('idle', true);
        }
      }
    }

    if (cursors.up.isDown && touchGround == true || keyboard.W.isDown && touchGround == true)
    {
        player.setVelocityY(speedJump);
        player.anims.play('jump');
        touchGround = false;
        jumped = true;
    }

    //SPARA
    if((cursors.space.isDown || keyboard.ENTER.isDown) && numProjectile>0 && shot == false)
    {
      if(sideRight == true)
      {
        projectile = this.matter.add.sprite(player.x+player.width, player.y, "fireball", undefined, {
          name: "projectile"
        });
        projectile.setFixedRotation();

        //MOVIMENTO PROIETTILE
        projectile.setVelocityX(speed*3);
        projectile.setIgnoreGravity(true);
        projectile.setFriction(0);

        this.time.delayedCall(2500, () => {//DOPO x SECONDI SE NON HA ANCORA TOCCATO NULLA SI DISTRUGGE
          projectile.destroy();
        });
      }
      else
      {
        projectile = this.matter.add.sprite(player.x-player.width, player.y, "fireball", undefined, {
          name: "projectile"
        });
        projectile.setFixedRotation();

        //MOVIMENTO PROIETTILE
        projectile.setVelocityX(-(speed*3));
        projectile.setIgnoreGravity(true); //RIMUOVE LA GRAVITA AL PROIETTILE
        projectile.setFriction(0);//RIMUOVE IL RALLENTAMENTO

        this.time.delayedCall(2500, () => {//DOPO x SECONDI SE NON HA ANCORA TOCCATO NULLA SI DISTRUGGE
          projectile.destroy();
        });
      }

      //PROJECTILE COLLISION
        projectile.setOnCollideActive(pair => {
          if(pair.bodyA.name == "star")
          {
          }
          else
          {
            if(pair.bodyA.name == "health" || pair.bodyA.name == "stairs")
            {
            }
            else
            {
              if(pair.bodyA.name == "spikes" || pair.bodyA.name == "border")
              {
                projectile.destroy();
              }
              else
              {
                switch (pair.bodyA.gameObject.name)
                {
                  case "player": break;

                  case "spider": distruggi(pair.bodyA, enemies);
                                 projectile.destroy();
                                 break;

                  case "fish":   distruggi(pair.bodyA, enemies);
                                 projectile.destroy();
                                 break;

                  case "door":   projectile.destroy();
                                 break;

                  case "door1":  projectile.destroy();
                                 break;

                  default:       projectile.destroy();
                                 break;
                }
              }
            }
          }

        });

      numProjectile--;
      shot = true;


      reloadTime = Math.floor(dt);
      startReload = true;

       this.time.delayedCall(1500, () => {
         shot = false;
         startReload = false;
       });
    }

    //INTERAGISCI CON GLI OGGETTI
    if((cursors.shift.isDown || keyboard.E.isDown) && doorSwitch[0][1] && doorSwitch[0][2])
    {
      if(doorSwitch[0][3] == true)
      {
        items[switch1Index].anims.play("switchRight", true);
        doorSwitch[0][3] = false;
        doorSwitch[0][2] = false;
        items[door1Index].setSensor(true);
        this.time.delayedCall(500, () => {
          doorSwitch[0][2] = true;
        });
      }
      else
      {
        items[switch1Index].anims.play("switchLeft", true);
        doorSwitch[0][3] = true;
        doorSwitch[0][2] = false;
        items[door1Index].setSensor(false);
        this.time.delayedCall(500, () => {
          doorSwitch[0][2] = true;
        });
      }
    }

    if((cursors.shift.isDown || keyboard.E.isDown) && touchSwitch && switchChanged)
    {
      if(switchLeft == true)
      {
        items[switchIndex].anims.play("switchRight", true);
        switchLeft = false;
        switchChanged = false;
        this.time.delayedCall(500, () => {
          switchChanged = true;
        });
      }
      else
      {
        items[switchIndex].anims.play("switchLeft", true);
        switchLeft = true;
        switchChanged = false;
        this.time.delayedCall(500, () => {
          switchChanged = true;
        });
      }
    }
  }
  else
  {
      player.anims.play('hurth', true);
      this.time.delayedCall(1500, () => {
        this.scene.pause();
        document.getElementById('dead').style.visibility = "visible";
        document.getElementById("riavviaBtn").focus();
        document.getElementById("riavviaBtn").onclick = () =>{
          location.reload();
        }
      });
  }

  //MOVIMENTO NEMICO
  if((Math.floor(dt/1000))%2 == 0)
  {
    for (var i = 0; i < enemies.length; i++) {
      enemies[i].setVelocityX(enemySpeed);
      enemies[i].flipX = false;

      switch(enemies[i].name){
        case "spider": enemies[i].anims.play("spiderWalk", true);
                       break;
        case "fish":   enemies[i].anims.play("fishWalk", true);
                       break;
      }
    }
  }
  else
  {
    for (var i = 0; i < enemies.length; i++) {
      enemies[i].setVelocityX(-enemySpeed);
      enemies[i].flipX = true;

      switch(enemies[i].name){
        case "spider": enemies[i].anims.play("spiderWalk", true);
                       break;
        case "fish":   enemies[i].anims.play("fishWalk", true);
                       break;
      }
    }
  }
}
//ALTRE FUNZIONI
//UNICO METODO PER DISTRUGGERE LE STELLE
function collect(obj, star)
{
  for (var i = 0; i < star.length; i++) {
    if(obj.parent.gameObject == star[i])
    {
      star[i].destroy();
      star.splice(i, 1);
      scoreStar++;
    }
  }
}

function distruggi(obj, arr)
{
  for (var i = 0; i < arr.length; i++) {
    if(obj.parent.gameObject == arr[i])
    {
      arr[i].destroy();
      arr.splice(i, 1);
    }
  }
}

function barLife(life)
{
  lifeGraphics.clear();
  lifeBar.clear();
  lifeGraphics.fillStyle(0x808080);
  lifeGraphics.fillRoundedRect(textProjectile.x, textProjectile.y + textProjectile.height, 200, 20, 5) //x, y, width, height, raggio curva angoli
  lifeBar.fillStyle(0x00ff00);
  lifeBar.fillRoundedRect(textProjectile.x, textProjectile.y + textProjectile.height, life, 20, 5)
}

function barReload(time)
{
  reloadGraphics.clear();
  reloadBar.clear();
  reloadGraphics.fillStyle(0x808080);
  reloadGraphics.fillRoundedRect(player.x - player.width/2, player.y - player.height/1.5, player.width, 10, 5) //x, y, width, height, raggio curva angoli
  reloadBar.fillStyle(0xffffff);
  reloadBar.fillRoundedRect(player.x - player.width/2, player.y - player.height/1.5, time, 10, 5)
}

function posizione(obj, arr)
{
  for (var i = 0; i < arr.length; i++) {
    if(obj.parent.gameObject == arr[i])
    {
      return i;
    }
  }
  return null;
}
